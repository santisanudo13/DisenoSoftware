package extras;

import java.util.LinkedList;
import java.util.List;

import p07Disenyo.excepciones.NoSeHaPodidoConectarABBDD;
import p08Disenyo.domain.Artista;
import p08Disenyo.domain.Creador;
import p08Disenyo.domain.Serie;
import p08Disenyo.proxy.SerieEstandarProxy;
import p08Disenyo.proxy.SerieEstandarReal;
import p08Disenyo.proxy.SerieGoldProxy;
import p08Disenyo.proxy.SerieGoldReal;

import p09disenyo.dto.AgregarSerieDTO;

/**
 * Assembler para el DTO perteneciente a la interfaz AgregarSerie
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class AgregarSerieDTOAssembler {

	private static AgregarSerieDTOAssembler serieAssembler;

	private AgregarSerieDTOAssembler(){}

	/**
	 * Singleton
	 * @return instancia unica del assembler
	 */
	public static AgregarSerieDTOAssembler getInstance(){
		if(serieAssembler==null){
			serieAssembler = new AgregarSerieDTOAssembler();
		}
		return serieAssembler;
	}

	/**
	 * Metodo para obtener el DTO asociado a la interfaz
	 * @param s
	 * @return
	 * @throws NoSeHaPodidoConectarABBDD
	 */
	public AgregarSerieDTO getSerie(Serie s) throws NoSeHaPodidoConectarABBDD{
		String nombreSerie = s.getNombre();
		String sinopsis = s.getSinopsis();

		String tipoSerie;
		
		if(s instanceof SerieEstandarProxy || s instanceof SerieEstandarReal){
			tipoSerie = "Estandar";		
		}else if(s instanceof SerieGoldProxy || s instanceof SerieGoldReal){
			tipoSerie= "Gold";
		}else{ //if(s instanceof SerieSilverProxy || s instanceof SerieSilverReal){
			tipoSerie = "Silver";
		}

		Creador c = s.getCreador();

		String creador = c.getNombre() + " " + c.getApellido1() + " " + c.getApellido2();

		List<String> artistas = new LinkedList<String>();

		for(Artista a:s.getArtistas()){
			String artista = a.getNombre() + " " + a.getApellido1() + " " + a.getApellido2();
			artistas.add(artista);
		}

		return new AgregarSerieDTO(nombreSerie,tipoSerie,sinopsis,creador,artistas);
	}

}
