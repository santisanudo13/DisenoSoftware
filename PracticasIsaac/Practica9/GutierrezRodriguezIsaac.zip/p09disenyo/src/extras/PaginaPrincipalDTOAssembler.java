package extras;

import java.util.LinkedList;
import java.util.List;

import p08Disenyo.domain.Serie;
import p08Disenyo.domain.Usuario;
import p09disenyo.dto.PaginaPrincipalDTO;

/**
 * Assembler para el DTO asociado a la interfaz PaginaPrincipal
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class PaginaPrincipalDTOAssembler {
	
	private static PaginaPrincipalDTOAssembler paginaPrincipalAssembler;

	private PaginaPrincipalDTOAssembler(){}

	/**
	 * Singleton
	 * @return instancia unica del assembler
	 */
	public static PaginaPrincipalDTOAssembler getInstance(){
		if(paginaPrincipalAssembler==null){
			paginaPrincipalAssembler = new PaginaPrincipalDTOAssembler();
		}
		return paginaPrincipalAssembler;
	}

	/**
	 * Metodo para obtener el DTO de la interfaz PaginaPrincipal
	 * @param u
	 * @return
	 */
	public PaginaPrincipalDTO getPaginaPrincipal(Usuario u){

		List<String> seriesEmpezadas = new LinkedList<String>();
		List<String> seriePendientes = new LinkedList<String>();
		List<String> seriesTerminadas = new LinkedList<String>();

		for(Serie s:u.getSeriesComenzadas()){
			String serie = s.getNombre();
			seriePendientes.add(serie);
		}
		
		for(Serie s:u.getSeriesPendientes()){ 
			String serie = s.getNombre();
			seriesEmpezadas.add(serie);
		}
		
		for(Serie s:u.getSeriesTerminadas()){
			String serie = s.getNombre();
			seriesTerminadas.add(serie);
		}

		return new PaginaPrincipalDTO(seriesEmpezadas,seriePendientes,seriesTerminadas);
	}

}
