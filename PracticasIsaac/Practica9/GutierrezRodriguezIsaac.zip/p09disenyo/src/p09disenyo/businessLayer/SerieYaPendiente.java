package p09disenyo.businessLayer;

public class SerieYaPendiente extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
