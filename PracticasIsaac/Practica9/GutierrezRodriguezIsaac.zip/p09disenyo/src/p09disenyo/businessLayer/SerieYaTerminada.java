package p09disenyo.businessLayer;

public class SerieYaTerminada extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
