package p09disenyo.businessLayer;

public class SerieYaComenzada extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
