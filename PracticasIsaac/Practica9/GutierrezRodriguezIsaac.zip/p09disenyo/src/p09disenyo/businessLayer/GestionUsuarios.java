package p09disenyo.businessLayer;

import java.util.Date;
import java.util.List;

import p07Disenyo.excepciones.NoSeHaPodidoConectarABBDD;
import p08Disenyo.datamappers.SerieDataMapper;
import p08Disenyo.domain.Factura;
import p08Disenyo.domain.Serie;
import p08Disenyo.domain.Usuario;
import p08Disenyo.domain.Visualizacion;
import p09disenyo.businessLayerInterfaces.IGestionUsuarios;
import p09disenyo.dto.AgregarSerieDTO;
import p09disenyo.dto.CapituloDTO;
import p09disenyo.dto.FacturaDTO;
import p09disenyo.dto.PaginaPrincipalDTO;
import p09disenyo.interfacesMocks.IFacturaDataMapper;
import p09disenyo.interfacesMocks.IUsuarioDataMapper;

import static org.mockito.Mockito.*;

/**
 * Gestion Usuarios
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class GestionUsuarios implements IGestionUsuarios {

	/**
	 * Metodo para el login de los usuarios
	 * @param usuario
	 */
	@Override
	public void autenticarse(Usuario usuario) {

	}

	/**
	 * Metodo para el registro de usuarios
	 * @param usuario
	 */
	@Override
	public void registrarse(Usuario usuario) {

	}

	/**
	 * Metodo para obtener los cargos del usuario
	 * @return cargos del usuario
	 */
	@Override
	public List<FacturaDTO> verCargos() {
		return null;
	}

	/**
	 * Metodo para obtener los cargos del usuario pertenecientes a un determinado mes
	 * @return cargos del usuario
	 */
	@Override
	public FacturaDTO verCargos(Date fecha) {
		return null;
	}

	/**
	 * Metodo para obtener la pagina principal del usuario
	 * @return pagina principal del usuario
	 */
	@Override
	public PaginaPrincipalDTO obtenerEspacioPersonal() {
		return null;
	}

	/**
	 * Metodo para anadir una nueva serie al espacio personal del usuario
	 * @param serie
	 * @throws NoSeHaPodidoConectarABBDD 
	 */
	@Override
	public void anadirSerieAEspacioPersonal(AgregarSerieDTO serie, long idUsuario) throws NoSeHaPodidoConectarABBDD, 
	SerieYaPendiente, SerieYaComenzada, SerieYaTerminada {

		SerieDataMapper serieMapper = new SerieDataMapper();
		Serie serie2 = serieMapper.readSerie(serie.getId());

		IUsuarioDataMapper usuarioMapper = mock(IUsuarioDataMapper.class);
		Usuario usuario = usuarioMapper.readUsuario(idUsuario);

		List<Serie> seriesPendientes = usuario.getSeriesPendientes();
		List<Serie> seriesComenzadas = usuario.getSeriesComenzadas();
		List<Serie> seriesTerminadas = usuario.getSeriesTerminadas();

		if(seriesPendientes.contains(serie2)) {
			throw new SerieYaPendiente();
		} else if(seriesComenzadas.contains(serie2)) {
			throw new SerieYaComenzada();
		} else if(seriesTerminadas.contains(serie2)) {
			throw new SerieYaTerminada();
		} else {
			usuario.getSeriesPendientes().add(serie2);
		}

		usuarioMapper.updateUsuario(usuario);

	}

	/**
	 * Metodo para anadir un cargo a la factura mensual de un usuario
	 * @param visualizacion
	 */
	@Override
	public void anadirCargoAFactura(Visualizacion visualizacion) throws NoSeHaPodidoConectarABBDD {

		IFacturaDataMapper facturaMapper = mock(IFacturaDataMapper.class);
		Factura factura = facturaMapper.obtenerFacturaActualUsuario(visualizacion.getUsuario().getId());

		factura.anadirCargo(visualizacion);

		facturaMapper.updateFactura(factura);

	}

	/**
	 * Metodo para cobrar un mes al usuario
	 * @param fecha
	 */
	@Override
	public void facturarMes(Date fecha) {}

	/**
	 * Metodo para visualizar un capitulo
	 * @param capitulo
	 */
	@Override
	public void visualizarCapitulo(CapituloDTO capitulo) {}

}
