package p09disenyo.businessLayer;

import java.util.List;

import p09disenyo.businessLayerInterfaces.IGestionSeriesUsuario;
import p09disenyo.dto.AgregarSerieDTO;
import p09disenyo.dto.VerSerieDTO;

/**
 * Gestion Series
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class GestionSeries implements IGestionSeriesUsuario {

	/**
	 * Metodo para ver la informacion de una serie
	 * @return informacion de una serie
	 */
	@Override
	public VerSerieDTO verSerie() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Metodo para listar las series
	 * @return lista de series
	 */
	@Override
	public List<AgregarSerieDTO> listarSeries() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Metodo para buscar series por su nombre
	 * @param nombre
	 * @return series obtenidas
	 */
	@Override
	public List<AgregarSerieDTO> buscarSeriesPorNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Metodo para buscar series por su letra inicial
	 * @param letraInicial
	 * @return series obtenidas
	 */
	@Override
	public List<AgregarSerieDTO> buscarSeriesPorLetraInicial(char letraInicial) {
		// TODO Auto-generated method stub
		return null;
	}

}
