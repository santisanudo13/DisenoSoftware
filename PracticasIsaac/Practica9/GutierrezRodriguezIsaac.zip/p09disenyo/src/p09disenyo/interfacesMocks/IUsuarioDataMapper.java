package p09disenyo.interfacesMocks;

import p07Disenyo.excepciones.NoSeHaPodidoConectarABBDD;
import p08Disenyo.domain.Usuario;

/**
 * Interfaz para los mocks utilizados en la implementacion de los metodos de negocio
 * @author Isaac Gutierrez Rodriguez
 *
 */
public interface IUsuarioDataMapper {
	
	public Usuario insertUsuario(Usuario u) throws NoSeHaPodidoConectarABBDD;

	public void updateUsuario(Usuario u) throws NoSeHaPodidoConectarABBDD;

	public void deleteUsuario(Usuario u) throws NoSeHaPodidoConectarABBDD;

	public Usuario readUsuario(long id) throws NoSeHaPodidoConectarABBDD;

}
