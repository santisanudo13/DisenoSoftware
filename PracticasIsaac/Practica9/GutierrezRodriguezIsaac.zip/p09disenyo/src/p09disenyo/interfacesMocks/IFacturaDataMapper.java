package p09disenyo.interfacesMocks;

import p07Disenyo.excepciones.NoSeHaPodidoConectarABBDD;
import p08Disenyo.domain.Factura;

/**
 * Interfaz para los mocks utilizados en la implementacion de los metodos de negocio
 * @author Isaac Gutierrez Rodriguez
 *
 */
public interface IFacturaDataMapper {
	
	public Factura insertFactura(Factura f) throws NoSeHaPodidoConectarABBDD;

	public void updateFactura(Factura f) throws NoSeHaPodidoConectarABBDD;

	public void deleteFactura(Factura f) throws NoSeHaPodidoConectarABBDD;

	public Factura readFactura(long id) throws NoSeHaPodidoConectarABBDD;
	
	public Factura obtenerFacturaActualUsuario(long idUsuario) throws NoSeHaPodidoConectarABBDD;

}
