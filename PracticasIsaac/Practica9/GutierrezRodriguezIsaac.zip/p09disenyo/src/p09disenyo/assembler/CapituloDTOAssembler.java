package p09disenyo.assembler;

import p08Disenyo.domain.Capitulo;
import p08Disenyo.domain.Usuario;
import p08Disenyo.domain.Visualizacion;
import p09disenyo.dto.CapituloDTO;

/**
 * Assembler para la creacion del DTO VerSerie
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class CapituloDTOAssembler {

	private static CapituloDTOAssembler capituloAssembler;

	private CapituloDTOAssembler(){}

	/**
	 * Singleton
	 * @return instancia unica del assembler
	 */
	public static CapituloDTOAssembler getInstance(){
		if(capituloAssembler==null){
			capituloAssembler = new CapituloDTOAssembler();
		}
		return capituloAssembler;
	}

	/**
	 * Metodo para obtener el DTO de los capitulos para la interfaz VerSerie
	 * @param c
	 * @param u
	 * @return dto del capitulo
	 */
	public CapituloDTO getCapitulo(Capitulo c, Usuario u){

		String titulo = c.getTitulo();
		int numCapitulo = c.getNumCapitulo();
		String enlace = c.getEnlace();

		Capitulo capitulo;
		boolean visto = false;
		
		for(Visualizacion v:u.getVisualizaciones()){
			capitulo = v.getCapitulo();
			if(capitulo.equals(c)){
				visto = true;
			}
		}		

		return new CapituloDTO(titulo, numCapitulo, enlace, visto);

	}

}
