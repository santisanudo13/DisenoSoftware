package p09disenyo.assembler;

import java.util.LinkedList;
import java.util.List;

import p07Disenyo.excepciones.NoSeHaPodidoConectarABBDD;

import p08Disenyo.domain.Serie;
import p08Disenyo.domain.Temporada;
import p08Disenyo.domain.Usuario;
import p08Disenyo.proxy.SerieEstandarProxy;
import p08Disenyo.proxy.SerieEstandarReal;
import p08Disenyo.proxy.SerieGoldProxy;
import p08Disenyo.proxy.SerieGoldReal;

import p09disenyo.dto.TemporadaDTO;
import p09disenyo.dto.VerSerieDTO;

/**
 * Assembler para la creacion del DTO VerSerie
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class VerSerieDTOAssembler {

	private static VerSerieDTOAssembler serieAssembler;

	private VerSerieDTOAssembler(){}

	/**
	 * Singleton
	 * @return instancia unica del assembler
	 */
	public static VerSerieDTOAssembler getInstance(){
		if(serieAssembler==null){
			serieAssembler = new VerSerieDTOAssembler();
		}
		return serieAssembler;
	}

	/**
	 * Metodo que retorna el DTO para la interfaz VerSerie
	 * @param s
	 * @param u
	 * @return DTO de la interfaz VerSerie
	 * @throws NoSeHaPodidoConectarABBDD
	 */
	public VerSerieDTO getSerie(Serie s, Usuario u) throws NoSeHaPodidoConectarABBDD{
		String nombreSerie = s.getNombre();
		String tipoSerie;
		
		if(s instanceof SerieEstandarProxy || s instanceof SerieEstandarReal){
			tipoSerie = "Estandar";		
		}else if(s instanceof SerieGoldProxy || s instanceof SerieGoldReal){
			tipoSerie= "Gold";
		}else{ //if(s instanceof SerieSilverProxy || s instanceof SerieSilverReal)
			tipoSerie = "Silver";
		}

		List<TemporadaDTO> temporadas = new LinkedList<TemporadaDTO>();

		for(Temporada t:s.getTemporadas()){
			TemporadaDTO temporada = TemporadaDTOAssembler.getInstance().getTemporada(t,u);
			temporadas.add(temporada);
		}

		return new VerSerieDTO(nombreSerie,tipoSerie,temporadas);
	}

}
