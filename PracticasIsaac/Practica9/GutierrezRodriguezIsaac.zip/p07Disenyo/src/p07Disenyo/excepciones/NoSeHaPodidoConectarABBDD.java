package p07Disenyo.excepciones;

/**
 * Excepcion para el tratamiento de los errores en la conexion a la BBDD
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class NoSeHaPodidoConectarABBDD extends Exception {

	private static final long serialVersionUID = 4198351989918986936L;

}
