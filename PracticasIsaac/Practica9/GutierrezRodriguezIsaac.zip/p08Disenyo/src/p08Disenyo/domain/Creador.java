package p08Disenyo.domain;

/**
 * Creador
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class Creador extends Persona {
	
	/**
	 * Constructor
	 * @param nombre
	 * @param apellido1
	 * @param apellido2
	 */
	public Creador(String nombre, String apellido1, String apellido2) {
		super(nombre, apellido1, apellido2);
	}

}
