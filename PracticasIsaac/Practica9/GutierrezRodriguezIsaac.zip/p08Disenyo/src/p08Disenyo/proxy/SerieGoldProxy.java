package p08Disenyo.proxy;

import java.util.List;

import p07Disenyo.excepciones.NoSeHaPodidoConectarABBDD;
import p08Disenyo.domain.Artista;
import p08Disenyo.domain.Creador;
import p08Disenyo.domain.Serie;
import p08Disenyo.domain.Temporada;

/**
 * Proxy de la SerieGold
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class SerieGoldProxy extends Serie {

	private SerieGoldReal serieReal;

	/**
	 * Constructor
	 * @param nombre
	 * @param sinopsis
	 */
	public SerieGoldProxy(String nombre, String sinopsis) {
		super(nombre, sinopsis);
	}

	/* Metodos para gestionar el lazy load a traves del objeto de la "Serie Real" */

	@Override
	public Creador getCreador() throws NoSeHaPodidoConectarABBDD {

		if(serieReal == null){
			this.serieReal = new SerieGoldReal(getNombre(),getSinopsis());
		}

		return serieReal.getCreador();
	}

	public List<Artista> getArtistas() throws NoSeHaPodidoConectarABBDD{

		if(serieReal == null){
			this.serieReal = new SerieGoldReal(getNombre(),getSinopsis());
		}

		return serieReal.getArtistas();
	}

	public List<Temporada> getTemporadas() throws NoSeHaPodidoConectarABBDD{

		if(serieReal == null){
			this.serieReal = new SerieGoldReal(getNombre(),getSinopsis());
		}

		return serieReal.getTemporadas();
	}

	@Override
	public void setCreador(Creador creador) {
		serieReal.setCreador(creador);
	}

	@Override
	public void setArtistas(List<Artista> artistas) {
		serieReal.setArtistas(artistas);
	}

	@Override
	public void setTemporadas(List<Temporada> temporadas) {
		serieReal.setTemporadas(temporadas);
	}

}
