package p08Disenyo.domain;

/**
 * Artista
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class Artista extends Persona {

	/**
	 * Constructor
	 * @param nombre
	 * @param apellido1
	 * @param apellido2
	 */
	public Artista(String nombre, String apellido1, String apellido2) {
		super(nombre, apellido1, apellido2);
	}

}
