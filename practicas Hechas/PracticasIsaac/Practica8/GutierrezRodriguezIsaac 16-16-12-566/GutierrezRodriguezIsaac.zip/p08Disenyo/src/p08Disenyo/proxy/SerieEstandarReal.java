package p08Disenyo.proxy;

import java.util.List;

import p07Disenyo.excepciones.NoSeHaPodidoConectarABBDD;
import p08Disenyo.datamappers.SerieDataMapper;
import p08Disenyo.domain.Artista;
import p08Disenyo.domain.Creador;
import p08Disenyo.domain.Serie;
import p08Disenyo.domain.Temporada;

/**
 * Objeto SerieEstandar "Real" para obtener de la bbdd los datos mediante la estrategia lazy load
 * @author Isaac Gutierrez Rodriguez
 *
 */
public class SerieEstandarReal extends Serie {

	/**
	 * Constructor
	 * @param nombre
	 * @param sinopsis
	 */
	public SerieEstandarReal(String nombre, String sinopsis) {
		super(nombre, sinopsis);
	}

	/* Metodos para obtener los datos, a traves de los data mappers, de la BBDD */

	@Override
	public Creador getCreador() throws NoSeHaPodidoConectarABBDD {
		this.creador = new SerieDataMapper().findSerieCreator(this);
		return creador;
	}

	@Override
	public List<Artista> getArtistas() throws NoSeHaPodidoConectarABBDD {
		this.artistas = new SerieDataMapper().findSerieArtists(this);
		return artistas;
	}

	@Override
	public List<Temporada> getTemporadas() throws NoSeHaPodidoConectarABBDD {
		this.temporadas = new SerieDataMapper().findSerieSeasons(this);
		return temporadas;
	}

}
